
DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_code` varchar(300) DEFAULT NULL,
  `account_name` varchar(300) DEFAULT NULL,
  `account_type` varchar(300) DEFAULT NULL,
  `account_description` text,
  `sub_ac_id` int(11) DEFAULT NULL,
  `opening_balance` double DEFAULT '0',
  `balance_type` varchar(330) DEFAULT NULL,
  `account_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `accounts` VALUES("7","1-2-7","HBL","assets","","2","0",NULL,"2019-03-02 21:40:36");
INSERT INTO `accounts` VALUES("8","1-2-8","Meezan","assets","","2","0",NULL,"2019-03-02 21:41:42");
INSERT INTO `accounts` VALUES("10","6-8-9","new assets","equity","","8","0",NULL,"2019-03-03 15:41:20");



DROP TABLE IF EXISTS `assign_module`;

CREATE TABLE `assign_module` (
  `assign_module_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role` varchar(300) DEFAULT NULL,
  `menu_page` varchar(300) DEFAULT NULL,
  `assign_module_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`assign_module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=latin1;

INSERT INTO `assign_module` VALUES("13","developer","add_remove_user_roles.php","2019-02-14 02:03:21");
INSERT INTO `assign_module` VALUES("14","developer","user_role_management.php","2019-02-14 02:03:22");
INSERT INTO `assign_module` VALUES("30","branch manager","branch.php","2019-02-14 22:10:52");
INSERT INTO `assign_module` VALUES("131","administrator","assign_rights.php","2019-03-04 02:11:42");
INSERT INTO `assign_module` VALUES("132","administrator","add_remove_user_roles.php","2019-03-04 02:11:42");
INSERT INTO `assign_module` VALUES("133","administrator","users.php","2019-03-04 02:11:42");
INSERT INTO `assign_module` VALUES("134","administrator","user_role_management.php","2019-03-04 02:11:43");
INSERT INTO `assign_module` VALUES("135","administrator","branch.php","2019-03-04 02:11:43");
INSERT INTO `assign_module` VALUES("136","administrator","chart_of_accounts.php","2019-03-04 02:11:43");
INSERT INTO `assign_module` VALUES("137","administrator","bank_payment.php","2019-03-04 02:11:43");
INSERT INTO `assign_module` VALUES("138","administrator","journal_voucher.php","2019-03-04 02:11:43");
INSERT INTO `assign_module` VALUES("139","administrator","account_voucher.php","2019-03-04 02:11:43");
INSERT INTO `assign_module` VALUES("140","administrator","search_voucher.php","2019-03-04 02:11:43");



DROP TABLE IF EXISTS `assign_user_role`;

CREATE TABLE `assign_user_role` (
  `assign_user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_role` varchar(300) DEFAULT NULL,
  `assign_user_role_remarks` text,
  `assign_user_role_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`assign_user_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO `assign_user_role` VALUES("15","5","administrator","Assign by User: admin@admin.com","2019-02-11 01:09:56");
INSERT INTO `assign_user_role` VALUES("16","5","branch manager","Assign by User: admin@admin.com","2019-02-11 01:09:56");
INSERT INTO `assign_user_role` VALUES("17","4","branch manager","Assign by User: admin@admin.com","2019-02-11 01:13:16");
INSERT INTO `assign_user_role` VALUES("18","2","developer","Assign by User: admin@admin.com","2019-02-11 02:00:07");
INSERT INTO `assign_user_role` VALUES("19","2","branch manager","Assign by User: admin@admin.com","2019-02-11 02:00:07");
INSERT INTO `assign_user_role` VALUES("33","1","administrator","Assign by User: admin","2019-03-01 00:20:26");



DROP TABLE IF EXISTS `branch`;

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(500) DEFAULT NULL,
  `branch_logo` varchar(300) NOT NULL DEFAULT 'user_default.png',
  `branch_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`branch_id`),
  UNIQUE KEY `branch_name` (`branch_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `branch` VALUES("1","head office","120655c64a59b409fc.png","2019-02-07 15:34:16");
INSERT INTO `branch` VALUES("2","susan road office","24405c64a54bd1980.png","2019-02-07 15:34:16");
INSERT INTO `branch` VALUES("4","new branch","192095c649c1024481.png","2019-02-14 03:37:04");



DROP TABLE IF EXISTS `master_ac`;

CREATE TABLE `master_ac` (
  `master_ac_id` int(11) NOT NULL AUTO_INCREMENT,
  `master_ac_name` varchar(300) DEFAULT NULL,
  `master_ac_type` varchar(300) DEFAULT NULL,
  `master_ac_description` text,
  `master_ac_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`master_ac_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `master_ac` VALUES("1","current assets","assets",NULL,"2019-02-28 23:12:26");
INSERT INTO `master_ac` VALUES("2","current liabilities ","liabilities",NULL,"2019-02-28 23:12:26");
INSERT INTO `master_ac` VALUES("3","equity","equity",NULL,"2019-02-28 23:12:59");
INSERT INTO `master_ac` VALUES("4","fixed assets","assets",NULL,"2019-02-28 23:12:59");
INSERT INTO `master_ac` VALUES("5","New Master Account","assets","sdjkndk","2019-03-03 11:06:11");
INSERT INTO `master_ac` VALUES("6","New Master Account","equity","","2019-03-03 15:41:00");



DROP TABLE IF EXISTS `menus`;

CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `page` text,
  `parent_id` int(11) DEFAULT NULL,
  `icon` varchar(300) NOT NULL DEFAULT 'fa fa-link',
  `sort_order` varchar(20) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `menus` VALUES("4","Assign Rights to Roles","assign_rights.php","5","fa fa-check",NULL,"2019-02-06 00:47:33");
INSERT INTO `menus` VALUES("5","Users","#",NULL,"fa fa-users","3","2019-02-06 00:47:58");
INSERT INTO `menus` VALUES("6","add/remove user roles","add_remove_user_roles.php","5","fa fa-cog",NULL,"2019-02-06 01:33:23");
INSERT INTO `menus` VALUES("7","add/remove users","users.php","5","fa fa-users",NULL,"2019-02-06 01:33:23");
INSERT INTO `menus` VALUES("9","User Role Management","user_role_management.php","5","fa fa-cog",NULL,"2019-02-11 00:04:56");
INSERT INTO `menus` VALUES("11","Manage Branch","branch.php","11","fa fa-link",NULL,"2019-02-14 03:07:26");
INSERT INTO `menus` VALUES("24","Accounts","#","0","fa fa-link",NULL,"2019-03-01 00:25:07");
INSERT INTO `menus` VALUES("25","Chart of Accounts","chart_of_accounts.php","24","fa fa-link",NULL,"2019-03-01 00:25:43");
INSERT INTO `menus` VALUES("26","Voucher","","24","fa fa-link",NULL,"2019-03-02 22:33:01");
INSERT INTO `menus` VALUES("27","Bank Payment","bank_payment.php","26","fa fa-link",NULL,"2019-03-02 22:39:10");
INSERT INTO `menus` VALUES("28","Journal Voucher","journal_voucher.php","26","fa fa-link",NULL,"2019-03-02 22:39:49");
INSERT INTO `menus` VALUES("29","Account Voucher","account_voucher.php","26","fa fa-link",NULL,"2019-03-03 16:22:30");
INSERT INTO `menus` VALUES("30","Search Voucher","search_voucher.php","26","fa fa-link",NULL,"2019-03-04 02:05:08");



DROP TABLE IF EXISTS `sub_ac`;

CREATE TABLE `sub_ac` (
  `sub_ac_id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_ac_name` varchar(300) DEFAULT NULL,
  `sub_ac_description` text,
  `master_ac_id` int(11) DEFAULT NULL,
  `sub_ac_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sub_ac_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `sub_ac` VALUES("1","account receivables ",NULL,"1","2019-02-28 23:21:45");
INSERT INTO `sub_ac` VALUES("2","bank accounts",NULL,"1","2019-02-28 23:21:45");
INSERT INTO `sub_ac` VALUES("3","cash accounts",NULL,"1","2019-02-28 23:22:02");
INSERT INTO `sub_ac` VALUES("7","Moiz","fefdreffddfiuh","5","2019-03-03 13:05:15");
INSERT INTO `sub_ac` VALUES("8","JKJKJK","","6","2019-03-03 15:41:09");



DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` varchar(300) DEFAULT NULL,
  `account_no` varchar(300) DEFAULT NULL,
  `debit` double DEFAULT '0',
  `credit` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `transaction` VALUES("4","29","7","8000","0");
INSERT INTO `transaction` VALUES("5","29","7","0","1000");
INSERT INTO `transaction` VALUES("6","29","6","0","2000");
INSERT INTO `transaction` VALUES("7","29","8","0","5000");
INSERT INTO `transaction` VALUES("8","30","8","7500","0");
INSERT INTO `transaction` VALUES("9","30","8","0","1500");
INSERT INTO `transaction` VALUES("10","30","7","0","6000");
INSERT INTO `transaction` VALUES("11","31","10","38100","0");
INSERT INTO `transaction` VALUES("12","31","10","0","2500");
INSERT INTO `transaction` VALUES("13","31","10","0","35600");
INSERT INTO `transaction` VALUES("14","32","10","2500","0");
INSERT INTO `transaction` VALUES("15","32","10","0","2500");
INSERT INTO `transaction` VALUES("16","33","10","15000","0");
INSERT INTO `transaction` VALUES("17","33","7","0","10000");
INSERT INTO `transaction` VALUES("18","33","8","0","5000");
INSERT INTO `transaction` VALUES("19","34","7","15000","0");
INSERT INTO `transaction` VALUES("20","34","","0","15000");
INSERT INTO `transaction` VALUES("21","34","","15000","0");
INSERT INTO `transaction` VALUES("22","34","","0","15000");
INSERT INTO `transaction` VALUES("23","34","","0","0");
INSERT INTO `transaction` VALUES("24","35","10","15000","0");
INSERT INTO `transaction` VALUES("25","35","7","0","15000");
INSERT INTO `transaction` VALUES("26","35","7","0","15000");
INSERT INTO `transaction` VALUES("27","35","10","15000","0");



DROP TABLE IF EXISTS `user_roles`;

CREATE TABLE `user_roles` (
  `user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_name` varchar(300) DEFAULT NULL,
  `user_role_status` varchar(300) NOT NULL DEFAULT 'enable',
  `user_role_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_role_id`),
  UNIQUE KEY `user_role_name` (`user_role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `user_roles` VALUES("1","administrator","enable","2019-02-08 00:26:05");
INSERT INTO `user_roles` VALUES("3","developer","enable","2019-02-08 00:59:38");
INSERT INTO `user_roles` VALUES("5","branch manager","enable","2019-02-08 01:02:24");



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(300) NOT NULL,
  `user_email` varchar(400) DEFAULT NULL,
  `user_password` text,
  `user_fullname` varchar(300) DEFAULT NULL,
  `user_branch` varchar(300) DEFAULT NULL,
  `user_address` text,
  `user_status` varchar(300) NOT NULL DEFAULT 'enable',
  `user_created_id` int(11) DEFAULT NULL,
  `user_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `users` VALUES("1","admin","admin@admin.com","21232f297a57a5a743894a0e4a801fc3","admin admin","head office","house # 66 B Block Gulberg Colony Faisalabad , 38000","enable",NULL,"2019-02-06 16:23:46");
INSERT INTO `users` VALUES("2","newuser","new@user.com","e6b306857e5d4afe00114863b6fbc795","new user","susan road office","nill","enable","1","2019-02-08 11:08:50");
INSERT INTO `users` VALUES("4","moixx","moixx.ansari43@gmail.com","2a77d9de907385ebf2b94d6b35fbcdd0","MOIZ IQBAL","susan road office","House # 66 B Block Gulberg Colony Faisalabad","enable","1","2019-02-08 12:02:20");
INSERT INTO `users` VALUES("5","abd","abd@gmail.com","202cb962ac59075b964b07152d234b70","Abdul Rehman","head office","House # 236 Street # 3 Green Town Umer Block","enable","1","2019-02-08 17:35:01");
INSERT INTO `users` VALUES("6","moiziqbal","moiz.iqbal55@gmail.com","8ca8f0e38f2823572277e322026317a8","Moiz Iqbal","head office","House 66 B Block Gulberg Colony Fsd","enable","1","2019-02-15 10:29:02");



DROP TABLE IF EXISTS `vouchers`;

CREATE TABLE `vouchers` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_type` varchar(300) DEFAULT NULL,
  `session` varchar(300) DEFAULT NULL,
  `payment_mode` varchar(300) DEFAULT NULL,
  `payment_mode_type` varchar(300) DEFAULT NULL,
  `voucher_no` varchar(300) DEFAULT NULL,
  `invoice_no` varchar(300) DEFAULT NULL,
  `bank_name` varchar(300) DEFAULT NULL,
  `cheque_no` varchar(300) DEFAULT NULL,
  `voucher_date` date DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  `bank_account` varchar(300) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `vouchers` VALUES("25","bpv","2019-2020","card","master","7878","7878","MCB","44545","2019-03-12","2019-03-21","HBL","vffffg");
INSERT INTO `vouchers` VALUES("26","bpv","2019-2020","card","visa","7878","7878","Alflah","34343","2019-03-18","2019-03-20","HBL","jkk");
INSERT INTO `vouchers` VALUES("27","bpv","2019-2020","card","master","77676","7878","7878","rrere","2019-03-12","2019-03-12","Meezan","fggfg");
INSERT INTO `vouchers` VALUES("28","bpv","2019-2020","card","","77676","7878","7878","rrere","2019-03-14","2019-03-03","Meezan","fggfg");
INSERT INTO `vouchers` VALUES("33","jpv","2019-2020","","","JPV-2019-03-29","7878","","","2019-03-06","0000-00-00","|","sddsdsdsds");
INSERT INTO `vouchers` VALUES("34","jpv","2019-2020","","","JPV-2019-03-34","7878","","","2019-03-13","0000-00-00","|","dsdds");
INSERT INTO `vouchers` VALUES("35","jpv","2019-2020","","","JPV-2019-03-35","7878","","","2019-03-26","0000-00-00","|","jhjjh");
