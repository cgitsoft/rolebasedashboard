<?php 
		session_start();
	/*
		Data base connection
	*/
@$dbc=mysqli_connect('localhost','root','','cgitsoft');
	if(!$dbc){
		echo mysqli_connect_error();
		exit();
	}

 ?>