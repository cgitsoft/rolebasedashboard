<?php 
	include_once 'functions.php';
	 /*Delete*/
 if (!empty($_REQUEST['id'])) {
 	# code...
 	$id=$_REQUEST['id'];
 	$table=$_REQUEST['table'];
 	$fld=$_REQUEST['fld'];
 	if(mysqli_query($dbc,"DELETE FROM $table WHERE $fld='$id'")){
 		$msg = "Data Has been deleted...";
 		$sts ="success";
 	}else{
 			$msg = mysqli_error($dbc);
 			$sts = "danger";
 	}
 	getMessage(@$msg,@$sts);
 }
  ?>
