<?php include_once 'functions.php'; ?>
<?php 
	if (isset($_REQUEST['email'])) {
		# code...
			// Always set content-type when sending HTML email
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
			# Common Headers 
			$headers .= 'From: TileSelect <noreply@tileselect.com>'.$eol; 
			// $headers .= "Message-ID:<".$now." TheSystem@".$_SERVER['SERVER_NAME'].">".$eol; 
			// $headers .= "X-Mailer: PHP v".phpversion().$eol;           // These two to help avoid spam-filters 

		if (mysqli_num_rows(mysqli_query($dbc,"SELECT * FROM users WHERE user_email='$_REQUEST[email]' OR username='$_REQUEST[email]'"))==1) {
			# code...
			$dir = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; 
	 			$dir=str_replace("inc/ajax_forget_email.php", "reset.php", $dir);
	 			$_SESSION['code']=md5(uniqid());
			$link=$dir."?keyID=".$_SESSION['code']."&email=".base64_encode($_REQUEST['email']);
			$subject = "Forget Email Confirm Link";
			$body='Thanks for Choosing TileSelect<br> Your password reset link has been created please <a href="'.$link.'">Click Here</a> to reset your password<br><br> Password Reset Link<br>'.$link."<br><br>Best Regards";
			if ($_REQUEST['server']=="localhost") {
				# code...
				require_once '../mailerClass/PHPMailerAutoload.php';
				send_email($_REQUEST['email'],$subject,$body);
			}else{
					mail($_REQUEST['email'], $subject, $body,$headers);
			}
			getMessage("Your reset password link has been sent to your email address","success");
		}else{
			getMessage($_REQUEST['email']." is not exist in the System","danger");
		}
	}else{
		getMessage("Problem","info");
	}
 ?>