<?php 
	include_once 'functions.php';
	 /*Delete*/
 if (!empty($_REQUEST['user_list'])) {
 	# code...
 	$user_list = $_REQUEST['user_list'];
	$assign_user_role=array();
	$getAssignRoles = mysqli_query($dbc,"SELECT * FROM assign_user_role WHERE user_id='$user_list'");
	while($fetchAssignRole = mysqli_fetch_assoc($getAssignRoles)){
		$assign_user_role[]=$fetchAssignRole['user_role'];
	}
	$getUserRole=mysqli_query($dbc,"SELECT * FROM user_roles WHERE user_role_status='enable'");
		while($fetchUserRole = mysqli_fetch_assoc($getUserRole)):
			if (in_array($fetchUserRole['user_role_name'], $assign_user_role)) {
				# code...
				$checked="checked";
			}else{
				$checked="";
			}
		 ?>
		 <div class="checkbox">
		 	<label class="lead">
		 		<input <?=@$checked?> type="checkbox" name="user_role_list[]" value="<?=$fetchUserRole['user_role_name']?>"> <?=ucwords($fetchUserRole['user_role_name']);?>
		 	</label>
		 </div><!-- checkbox -->
		<?php endwhile;
 }
  ?>
