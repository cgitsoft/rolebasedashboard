<?php 
	/* Getting information of login user*/
	@$voucher_code_string = date('Y')."-".date("m");

	@$fetchUser = mysqli_fetch_assoc(mysqli_query($dbc,"SELECT * FROM users WHERE user_email='$_SESSION[user_login]' OR username='$_SESSION[user_login]'"));
  			 $user_permission=array();
		     $files=array();
		     $parents=array();
		     $getUserRole = mysqli_query($dbc,"SELECT * FROM assign_user_role WHERE user_id='".$fetchUser['user_id']."'");
		     while($fetchUserRole = mysqli_fetch_assoc($getUserRole)){
		      $user_permission[]=$fetchUserRole['user_role'];
		      foreach($permissions[$fetchUserRole['user_role']] as $value){
		      	$p = explode('.', $value);
		        $files[]=$p[0];
		        $getParent = fetchRecord($dbc,"menus","page",$value);
		        $parents[]=$getParent['parent_id'];
		      }
		     }
		     $files=array_unique($files);
	/*
	Call Pages
	*/
	if (!empty($_REQUEST['nav'])) {
		# code...
		if (in_array(base64_decode($_REQUEST['nav']), $files) OR (($_REQUEST['nav']==base64_encode('developer_mode')) OR ($_REQUEST['nav']==base64_encode('profile')) )) {
			# code...
			$page = "pages/".base64_decode($_REQUEST['nav']).".php";
		}else{
			$page="pages/404.php";
		}
		
	}else{
		$page="pages/home.php";
	}
	
	
	/*
	Login Process
	*/
	if (isset($_REQUEST['login_btn'])) {
		# code...
		$user_email = validate_data($dbc,$_REQUEST['user_email']);
		$user_password = md5($_REQUEST['user_password']);
		$user_role=(empty($_REQUEST['role']))?"student":$_REQUEST['role'];
		$q = mysqli_query($dbc,"SELECT * FROM users WHERE (user_email='$user_email' OR username='$user_email') AND user_password='$user_password'");
		$count=mysqli_num_rows($q);
		if ($count==1) {
			# code...
			$_SESSION['user_login']=$user_email;
			$msg = "Logging...";
			$sts ="success";
			redirect('index.php',2000);
		}else{
			$msg = "Invalid Email or Password<br> Your might be choosen wrong actor";
			$sts = "danger";
		}
	}

	/*
	User Role Module
	*/
	if (isset($_REQUEST['add_role'])) {
		# code...
		$data = [
			'user_role_name'=>$_REQUEST['user_role_name'],
			'user_role_status'=>$_REQUEST['user_role_status'],
		];
		if (insert_data($dbc,"user_roles",$data)) {
			# code...
			$msg = "User Role Added Successfully";
			$sts = "success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}//insert
	if (!empty($_REQUEST['edit_user_role_id'])) {
		# code...
		$fetchUserRoleData=fetchRecord($dbc,"user_roles","user_role_id",base64_decode($_REQUEST['edit_user_role_id']));
		$user_role_btn='<button class="btn btn-primary" name="update_role">Edit Role</button>';
	}else{
		$user_role_btn='<button class="btn btn-success" name="add_role">Add Role</button>';
	}
	if (isset($_REQUEST['update_role'])) {
		# code...
		$data = [
			'user_role_name'=>$_REQUEST['user_role_name'],
			'user_role_status'=>$_REQUEST['user_role_status'],
		];
		if (update_data($dbc,"user_roles",$data,"user_role_id",base64_decode($_REQUEST['edit_user_role_id']))) {
			# code...
			$msg = "User Role Updated Successfully";
			$sts = "info";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}//update

	/*
	Update User Profile
	*/
	if (isset($_REQUEST['update_user_profile'])) {
		# code...
		$data = [
			'user_fullname'=>$_REQUEST['user_fullname'],
			'user_address'=>$_REQUEST['user_address'],
			'username'=>$_REQUEST['username'],
			'user_email'=>$_REQUEST['user_email'],
		];
		if (update_data($dbc,"users",$data,"user_id",$fetchUser['user_id'])) {
			# code...
			$msg = "Profile Updated...";
			$sts = "success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}
	/*
	Change User Password
	*/
	if (isset($_REQUEST['update_password'])) {
 	# code...
 	$msg="";
 	$old_password=md5($_REQUEST['old_password']);
 	$new_password=md5($_REQUEST['new_password']);
 	$confirm_password=md5($_REQUEST['confirm_password']);
	if (!empty($old_password)) {
		 		# code...
			if (@mysqli_num_rows(mysqli_query($dbc,"SELECT * FROM users WHERE user_id='$fetchUser[user_id]' AND user_password='$old_password'"))==1) {
				# code...
				if ($new_password==$confirm_password) {
					# code...
					$data=['user_password'=>$new_password];
					if (update_data($dbc,"users",$data,'user_id',$fetchUser['user_id'])) {
						# code...
						  $msg= " Password Updated <i class='glyphicon glyphicon-ok'></i>";
         				
         				redirect('login.php',2000);
         				unset($_SESSION['user_login']);
						$sts="success";
					}else{
						$msg=mysqli_error($dbc);
						$sts="danger";
					}
				}else{
					$msg="New or Confimed Password not Matched...";
					$sts="info";
				}

			}else{
				$msg="Old Password not Matched...";
				$sts="warning";
			}
	 	} 	
 
 	}//isset 

 	/*
	User Role Module
	*/
	if (isset($_REQUEST['add_user'])) {
		# code...
		$data = [
			'user_fullname'=>$_REQUEST['user_fullname'],
			'username'=>$_REQUEST['username'],
			'user_email'=>$_REQUEST['user_email'],
			'user_password'=>md5($_REQUEST['user_password']),
			'user_address'=>$_REQUEST['user_address'],
			'user_branch'=>$_REQUEST['user_branch'],
			'user_created_id'=>$fetchUser['user_id'],
			'user_status'=>$_REQUEST['user_status'],
		];
		if (insert_data($dbc,"users",$data)) {
			# code...
			$msg = "User Added Successfully";
			$sts = "success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}//insert
	if (!empty($_REQUEST['edit_user_id'])) {
		# code...
		$fetchUserData=fetchRecord($dbc,"users","user_id",base64_decode($_REQUEST['edit_user_id']));
		$user_btn='<button class="btn btn-primary" name="update_user">Edit User</button>';
	}else{
		$user_btn='<button type="submit" class="btn btn-success" name="add_user">Add User</button>';
	}
	if (isset($_REQUEST['update_user'])) {
		# code...
		$data = [
			'user_fullname'=>$_REQUEST['user_fullname'],
			'username'=>$_REQUEST['username'],
			'user_email'=>$_REQUEST['user_email'],
			'user_password'=>md5($_REQUEST['user_password']),
			'user_address'=>$_REQUEST['user_address'],
			'user_branch'=>$_REQUEST['user_branch'],
			'user_created_id'=>$fetchUser['user_id'],
			'user_status'=>$_REQUEST['user_status'],

		];
		if (update_data($dbc,"users",$data,"user_id",base64_decode($_REQUEST['edit_user_id']))) {
			# code...
			$msg = "User Updated Successfully";
			$sts = "info";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}//update

	/*
	Menu Moudle
	*/
	if (isset($_REQUEST['add_menu'])) {
		# code...
		$data = [
			'title'=>$_REQUEST['title'],
			'page'=>$_REQUEST['page'],
			'parent_id'=>$_REQUEST['parent_id'],
			'icon'=>'fa '.$_REQUEST['icon'],
		];
		if (insert_data($dbc,"menus",$data)) {
			# code...
			/*$txt='<div class="panel panel-default panel-body" style="padding: 20px">\n <div class="row">\n <div class="col-sm-8 pull-right">\n </div><!-- col -->\n <div class="col-sm-4 panel panel-default panel-body">\n </div><!-- col -->\n</div><!-- row --> </div><!-- box -->'; 
			$myfile = fopen("pages/".$_REQUEST['page'], "w") or die("Unable to open file!");
				fwrite($myfile, $txt);
				fclose($myfile);*/
			$msg = "Menu Added Successfully";
			$sts = "success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}//insert

	if (!empty($_REQUEST['edit_menu_id'])) {
		# code...
		$fetchMenu=fetchRecord($dbc,"menus","id",base64_decode($_REQUEST['edit_menu_id']));
		$menu_btn='<button class="btn btn-primary" name="update_menu">Edit Menu</button>';
	}else{
		$menu_btn='<button type="submit" class="btn btn-success" name="add_menu">Add Menu</button>';
	}
	if (isset($_REQUEST['update_menu'])) {
		# code...
		$data = [
			'title'=>$_REQUEST['title'],
			'page'=>$_REQUEST['page'],
			'parent_id'=>$_REQUEST['parent_id'],
			'icon'=>'fa '.$_REQUEST['icon'],
		];
		if (update_data($dbc,"menus",$data,"id",base64_decode($_REQUEST['edit_menu_id']))) {
			# code...
			$msg = "Menu Updated Successfully";
			$sts = "info";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}//update

	/*
	Add Branch
	*/
	if (isset($_REQUEST['add_branch'])) {
		# code...
		
		if ($_FILES['f']['tmp_name']) {
			# code...
			$dir="img/uploads/";
			upload_pic($_FILES['f'],$dir);
			$user_pic=$_SESSION['pic_name'];
		}else{
			$user_pic='user_default.png';
		}
		$data=[
			'branch_name'=>$_REQUEST['branch_name'],
			'branch_logo'=>$user_pic,
		];
		
		if (insert_data($dbc,"branch",$data)) {
			# code...
			$msg = "Branch Added";
			$sts ="success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}
	if (!empty($_REQUEST['edit_branch_id'])) {
		# code...
		$fetchBranchData=fetchRecord($dbc,"branch","branch_id",base64_decode($_REQUEST['edit_branch_id']));
		$branch_btn='<button class="btn btn-primary" name="update_branch">Edit Branch</button>';
	}else{
		$branch_btn='<button class="btn btn-success" name="add_branch">Add Branch</button>';
	}
	/*
	Update user Button
	*/
	if (isset($_REQUEST['update_branch'])) {
		# code...
		$data=[
			'branch_name'=>$_REQUEST['branch_name'],
		];
		if ($_FILES['f']['tmp_name']) {
			# code...
			$dir="img/uploads/";
			upload_pic($_FILES['f'],$dir);
			$user_pic=$_SESSION['pic_name'];
			$data['branch_logo']=$user_pic;
		}else{
			$user_pic='user_default.png';
		}
		
		
		if (update_data($dbc,"branch",$data,"branch_id",base64_decode($_REQUEST['edit_branch_id']))) {
			$msg = "Branch Updated";
			$sts ="success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}
	/*
	Reset Password
	*/
	if (isset($_REQUEST['reset_password'])) {
		# code...
		$new_password = md5($_REQUEST['new_password']);
		$confirm_password = md5($_REQUEST['confirm_password']);
		if ($new_password==$confirm_password) {
			# code...
			$data =[
				"user_password"=>$new_password
			];
			if (update_data($dbc,"users",$data,"user_email",base64_decode($_REQUEST['email']))) {
				# code...
				$msg = "Password has been reset. Redirecting....";
				$sts = "success";
				session_destroy();
				redirect('login.php',2000);
		}
			}
		else{
			$msg = "New or Confirm Password Not Matched";
			$sts = "danger";
		}
	}//isset
	/*
	Chart of Account
	*/
	/*
	Add Account
	*/
	if (isset($_REQUEST['add_account'])) {
		# code...
		$getLastAccountID = getLastID($dbc,"accounts","account_id")+1;
		$account_code = $_REQUEST['master_ac_id']."-".$_REQUEST['sub_ac_id']."-".$getLastAccountID;
		$data =[
			'account_code'=>$account_code,
			'account_type'=>strtolower($_REQUEST['account_type']),
			"sub_ac_id"=>$_REQUEST['sub_ac_id'],
			"account_name"=>$_REQUEST['account_name'],
			"account_description"=>$_REQUEST['account_description']
		];
		if (insert_data($dbc,"accounts",$data)) {
			$msg = "Account Added Successfully";
			$sts ="success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}
	/*
	Update Account
	*/
	if (isset($_REQUEST["update_account"])) {
		# code...
		$data =[
			"account_name"=>$_REQUEST['account_name'],
			"opening_balance"=>$_REQUEST['opening_balance'],
			'balance_type'=>"dr"
		];
		if (update_data($dbc,"accounts",$data,"account_id",$_REQUEST['account_id'])) {
			$msg = "Account Updated Successfully";
			$sts ="success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}
	if (isset($_REQUEST["update_account_data"])) {
		# code...
		$data =[
			'account_type'=>strtolower($_REQUEST['account_type']),
			"sub_ac_id"=>$_REQUEST['sub_ac_id'],
			"account_name"=>$_REQUEST['account_name'],
			"account_description"=>$_REQUEST['account_description']
		];
		if (update_data($dbc,"accounts",$data,"account_id",$_REQUEST['account_id'])) {
			$msg = "Account Updated Successfully";
			$sts ="success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}
	/*
	Add Master Account
	*/
	if (isset($_REQUEST['add_master_account'])) {
		# code...
		$data = [
			'master_ac_name'=>$_REQUEST['master_ac_name'],
			'master_ac_type'=>$_REQUEST['master_ac_type'],
			'master_ac_description'=>$_REQUEST['master_ac_description']
		];
		if (insert_data($dbc,"master_ac",$data)) {
			$msg = "Master Account Added Successfully";
			$sts ="success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}
	/*
	Add Sub Account
	*/
	if (isset($_REQUEST['add_sub_account'])) {
		# code...
		$data = [
			'sub_ac_name'=>$_REQUEST['sub_ac_name'],
			'master_ac_id'=>$_REQUEST['master_ac_id'],
			'sub_ac_description'=>$_REQUEST['sub_ac_description']
		];
		if (insert_data($dbc,"sub_ac",$data)) {
			$msg = "Sub Account Added Successfully";
			$sts ="success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}
	if (isset($_REQUEST['update_sub_account'])) {
		# code...
		$data = [
			'sub_ac_name'=>$_REQUEST['sub_ac_name'],
			'master_ac_id'=>$_REQUEST['master_ac_id'],
			'sub_ac_description'=>$_REQUEST['sub_ac_description'],
		];
		if (update_data($dbc,"sub_ac",$data,"sub_ac_id",$_REQUEST['sub_ac_id'])) {
			$msg = "Sub Account Updated Successfully";
			$sts ="success";
			redirectCurrentURL(800);
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}

	/*
	Voucher Module

	Add new Voucher
	*/
	if (isset($_REQUEST['add_voucher'])) {
		# code...
		$total = $_REQUEST['total_amount'];
		$data = [
			'voucher_type'=>$_REQUEST['voucher_type'],
			'session'=>$_REQUEST['session'],
			'voucher_no'=>$_REQUEST['voucher_no'],
			'invoice_no'=>$_REQUEST['invoice_no'],
			'voucher_date'=>$_REQUEST['voucher_date'],
			'payment_mode'=>getNull($_REQUEST['payment_mode']),
			'bank_name'=>getNull($_REQUEST['bank_name']),
			'cheque_no'=>getNull($_REQUEST['cheque_no']),
			'transfer_date'=>getNull($_REQUEST['transfer_date']),
			'bank_account'=>$_REQUEST['account_id']."|".$_REQUEST['bank_account'],
			'description'=>$_REQUEST['description'],
			'payment_mode_type'=>getNull($_REQUEST['payment_mode_type']),
		];
		if (insert_data($dbc,"vouchers",$data)) {
			# code...
			$voucher_id = mysqli_insert_id($dbc);
		
			// Bank Account and Cash Account Vocuhers
			if($_REQUEST['voucher_type']=="jpv"){
				for ($i=0; $i <count($_REQUEST['cr_amount']) ; $i++) { 
					# code...
					$data_transction =[
						'voucher_id'=>$voucher_id,
						'account_no'=>$_REQUEST['account_no'][$i],
						'debit'=>$_REQUEST['dr_amount'][$i],
						'credit'=>$_REQUEST['cr_amount'][$i],
	
					];
					$q=insert_data($dbc,"transaction",$data_transction);
				}
			}else{
				for ($i=0; $i <=count($_REQUEST['account_name']) ; $i++) { 
					# code...
					if($i==0){
						$debit=$total;
						$credit=0;
						$account_no=$_REQUEST['account_no'][$i];
					}else{
						$debit=0;
						$credit=$_REQUEST['amount'][$i-1];
						$account_no=$_REQUEST['account_no'][$i-1];
					}
					$data_transction =[
						'voucher_id'=>$voucher_id,
						'account_no'=>$account_no,
						'debit'=>$debit,
						'credit'=>$credit,
	
					];
					$q=insert_data($dbc,"transaction",$data_transction);
				}
			}//else
			if (@$q) {
				# code...
				$msg = "Voucher Added Successfully";
				$sts ="success";
				redirectCurrentURL(800);
			}else{
				$msg = mysqli_error($dbc);
				$sts = "danger";
			}//else
			
			
		}else{
			$msg = mysqli_error($dbc);
			$sts = "danger";
		}
	}

 ?>



