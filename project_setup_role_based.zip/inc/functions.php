<?php 
	session_start();
	/*
		Data base connection
	*/
		/*
	Define Constants
	*/
	define('TITLE', 'Convert Generation Information Technology - CGit');
	define('TITLE_MIDEL', 'CGit Soft');
	define('TITLE_SHORT', 'CGit');
	define('DB_NAME', 'cgitsoft');
	define('DB_USER', 'root');
	define('DB_PASSWORD', '');
	define('DB_HOST', 'localhost');
@$dbc=mysqli_connect('localhost','root','','rbac');
	if(!$dbc){
		echo mysqli_connect_error();
		exit();
	}

	/*
	Make functions to add  \\ and strip html tags
	*/
	function validate_data($dbc,$data){
		return mysqli_real_escape_string($dbc,strip_tags($data));
	}
	/*
	Make function for diplaying messages
	*/
	function getMessage($msg,$sts){
		echo '<div class="alert alert-'.$sts.'">'.$msg.'</div>';
	}
	

	/*
	Admin Role
	*/
	$permissions =array();
	$getUserRolesPermission = mysqli_query($dbc,"SELECT * FROM user_roles");
	while($fetchUserRolesPermission = mysqli_fetch_assoc($getUserRolesPermission)){
		$permissions[$fetchUserRolesPermission['user_role_name']]=array();
		$getUserRoleRights = mysqli_query($dbc,"SELECT * FROM assign_module WHERE user_role='$fetchUserRolesPermission[user_role_name]'");
		while($fetchUserRoleRights=mysqli_fetch_assoc($getUserRoleRights)){
			$permissions[$fetchUserRolesPermission['user_role_name']][]=$fetchUserRoleRights['menu_page'];
		}
	}
	/*$permissions =array(
		'admin'=>['add_user','assignCourse','degrees','departments','student_enroll','studentAttendanceSheet','markStudentAttendance','courses','users','contacts'],
		'teacher'=>['users','studentAttendanceSheet','viewAssignedCourses','markStudentAttendance','uploadLectures'],
		'student'=>['student_attendance','viewUploadedLecture'],
	);*/
 ?>
 
<?php 
	function debug_mode($array){
			echo "<pre>";
			print_r($array);
			exit;
	}
	function getNull($data){
		return (empty($data))?"":$data;
	}
 ?>
 <?php function getYesNo($data){
 	// return ($data==1)?'Yes':'No';
 	if ($data==0) {
 		# code...
 		return 'No';
 	}elseif($data==1){
 		return 'Yes';
 	}else{
 		return "Defaulter";
 	}
 	}
 	 function getEnDis($data){
 	// return ($data==1)?'Yes':'No';
 	if ($data=="enable") {
 		# code...
 		return '<label class="label label-success">Enable</label>';
 	}else{
 		return '<label class="label label-danger">disabled</label>';
 		}
 	}  ?>
 <?php function getDateFormat($format,$data){
 	return date($format,strtotime($data));
 	} ?>
<?php 
	function get($dbc,$table){
		return mysqli_query($dbc,"SELECT * FROM $table");
	}
 ?>
<?php 
	function getFetch($dbc,$table){
		return mysqli_fetch_assoc(mysqli_query($dbc,"SELECT * FROM $table"));
	}
 ?>
 <?php 
  function getSelectTag($data,$text){
    if (!empty($data)) {
      # code...
      echo "<option value='".$data."'>".$data."</option>";
    }else{
      echo "<option value=''>".$text."</option>";

    }
  }
 ?>
 <?php 
 function countIf($dbc,$arr){
 	echo (mysqli_num_rows($arr)==0)?"No Found":'';
 }
  ?>
 <?php 
 	function get2($dbc,$table1,$table2,$order="ASC"){
 		return mysqli_query($dbc, "SELECT $table1.user_name, $table2.feed_id, $table2.comment FROM $table1, $table2 WHERE $table1.user_id=$table2.user_id ORDER BY feed_id $order");
 	}
  ?>
  <?php 
  function deleteFromTable($dbc,$table,$fld="",$id){
  	global $sts;
 	global $msg;
  	$id = base64_decode($id);
	if (mysqli_query($dbc,"DELETE FROM $table WHERE $fld='$id'")) {
		# code...
		$msg =  "Deleted ....";
		$sts="danger";
	}else{
		$msg= mysqli_error($dbc);
		$sts="danger";
	}
  }
   ?>
   <?php 
	   	function redirect($url,$time=0){
	   		?>
			<script>
				setTimeout(function(){
					window.location="<?=$url?>";
				},<?=$time?>);
			</script>

	   		<?php
	   	}
    ?>
    <?php 
	   	function redirectCurrentURL($time=0){
	   		?>
			<script>
				setTimeout(function(){
					window.location=window.location.href;
				},<?=$time?>);
			</script>

	   		<?php
	   	}
    ?>


	<?php 
		function delete_all($dbc, $table, $array, $fld ){
		global $sts;
 		global $msg;
 		if(!empty($array)):
		foreach ($array as $data) {
		# code...
		$q = mysqli_query($dbc,"DELETE FROM $table WHERE $fld='$data'");
			
		}
		if ($q) {
				# code...
				$msg = "Data Deleted";
				$sts = "danger";	
		}else{
				$msg = mysqli_error($dbc);
				$sts = "danger";
			}
			endif;
		}
	 ?>
	 <?php function fetchRecord($dbc,$table,$fld,$data){
	 	return  mysqli_fetch_assoc(mysqli_query($dbc,"SELECT * FROM $table WHERE $fld='$data'"));
	 	} ?>

	 	<?php 
	 	function insert_data($dbc,$table,$data){
	 		global $msg;
	 		global $sts;
	 		$fld=$values="";
			$i=0;
			$comma=",";
			$count = count($data);
				foreach ($data as $index => $value) {
					# code...
					if(($count-1)==$i){
						$comma="";
					}
					$fld=$fld.$index.$comma;
					if ($index=!"post_body") {
						# code...
						$val =validate_data($dbc,$value);
					}else{
						$val =$value;
					}
					$values = $values."'".$val."'".$comma;
					$i++;
				}
				return mysqli_query($dbc,"INSERT INTO $table($fld) VALUES($values)");
	 	}

	 	 ?>
	 	<?php 
	 	function update_data($dbc,$table,$data,$col,$val){
	 		$set_data="";
			$i=0;
			$comma=",";
			$count = count($data);
			//debug_mode($data);
				foreach ($data as $index => $value) {
					# code...
					if(($count-1)==$i){
						$comma="";
					}
					$set_data=$set_data.$index."='".validate_data($dbc,$value)."'".$comma;
					$i++;
					
				}
				return mysqli_query($dbc,"UPDATE $table SET $set_data WHERE $col='$val'");
	 	}

	 	 ?>
		<?php 
		function countAll($dbc,$table){
			 return mysqli_num_rows(mysqli_query($dbc,"SELECT * FROM $table"));
			}
		 ?>	
<?php 
  // Count When
function countWhen($dbc,$table,$fld,$data){
return  mysqli_num_rows(mysqli_query($dbc,"SELECT * FROM $table WHERE $fld='$data'"));
} ?>
	<?php 
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
	    $ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
	    $ip = $_SERVER['REMOTE_ADDR'];
	}
	 ?>
<?php function upload_pic($file,$url){
	global $sts;
	global $msg;
	global $size;
	global $pic;
	// @$file= $_FILES['f'];
		$file_name = $file['name'];
		$temp_name = $file['tmp_name'];
		$size = $file['size'];
		// $type = $file['type'];
		$errors = $file['error'];
	$type = explode('.', $file_name);
	$type = $type[count($type)-1];	
	$pic = uniqid(rand()).'.'.$type;
	$_SESSION['pic_name'] = $pic;	
	$url = $url.$pic;
		if (!$temp_name) {
			# code...
			$sts="info";
			$msg= "Please Choose a File Before Clicking";
			
		}elseif($size>500000){
			$sts="info";
			$msg= "Not Allowed more than 5 MB file size";
			unlink($temp_name);
			// exit();
		}
		elseif(!preg_match("/\.(gif|jpg|png|jpeg)$/i", $file_name)){
			$sts="info";
			$msg= "Only .jpg , .png and .gif file types are allowed";
			unlink($temp_name);
			// exit();
		}elseif($errors==1){
			$sts="info";
			$msg= "Error while uploading....";
			unlink($temp_name);
			// exit();
		}
		if(move_uploaded_file($temp_name, $url)){
				return true;
			
		}
		else{
			$sts="info";
			$msg= "Not Uploaded...";
			@unlink($temp_name);
			//exit();
		}
		
			
	} 
	?>	
<?php function upload_file($file,$url){
	global $sts;
	global $msg;
	global $size;
	global $pic;
	// @$file= $_FILES['f'];
		$file_name = $file['name'];
		$temp_name = $file['tmp_name'];
		$size = $file['size'];
		// $type = $file['type'];
		$errors = $file['error'];
	$type = explode('.', $file_name);
	$type = $type[count($type)-1];	
	$pic = uniqid(rand()).'.'.$type;
	$_SESSION['file_name'] = $pic;	
	$url = $url.$pic;
		if (!$temp_name) {
			# code...
			$sts="info";
			$msg= "Please Choose a File Before Clicking";
			
		}elseif($size>500000){
			$sts="info";
			$msg= "Not Allowed more than 5 MB file size";
			unlink($temp_name);
			// exit();
		}
		elseif(!preg_match("/\.(doc|docx|xls|pdf)$/i", $file_name)){
			$sts="info";
			$msg= "Only .doc , .docx, .pdf and .xls file types are allowed";
			unlink($temp_name);
			// exit();
		}elseif($errors==1){
			$sts="info";
			$msg= "Error while uploading....";
			unlink($temp_name);
			// exit();
		}
		if(move_uploaded_file($temp_name, $url)){
				return true;
			
		}
		else{
			$sts="info";
			$msg= "Not Uploaded...";
			@unlink($temp_name);
			//exit();
		}
		
			
	} 
	/*
	Get Login User Roles and Make File Access
*/
	 
	/*
	Making dynamic Menu and Generating Multiple Level
	*/
	function show_menu($dbc){
		$menus='';
		$menus.=generate_multilevel_menu($dbc);
		return $menus;	
	}
	function generate_multilevel_menu($dbc,$parent_id=NULL){
		@$_SESSION['fetchUser'] = mysqli_fetch_assoc(mysqli_query($dbc,"SELECT * FROM users WHERE user_email='$_SESSION[user_login]' OR username='$_SESSION[user_login]'"));
			$per =array();
			$getUserRolesPermission = mysqli_query($dbc,"SELECT * FROM user_roles");
			while($fetchUserRolesPermission = mysqli_fetch_assoc($getUserRolesPermission)){
				$per[$fetchUserRolesPermission['user_role_name']]=array();
				$getUserRoleRights = mysqli_query($dbc,"SELECT * FROM assign_module WHERE user_role='$fetchUserRolesPermission[user_role_name]'");
				while($fetchUserRoleRights=mysqli_fetch_assoc($getUserRoleRights)){
					$per[$fetchUserRolesPermission['user_role_name']][]=$fetchUserRoleRights['menu_page'];
				}
			}
		     $u_p=[];
		     $files=array();
		     
		     $getUserRole = mysqli_query($dbc,"SELECT * FROM assign_user_role WHERE user_id='".$_SESSION['fetchUser']['user_id']."'");
		     while($fetchUserRole = mysqli_fetch_assoc($getUserRole)){
		      $u_p[]=$fetchUserRole['user_role'];
		      foreach($per[$fetchUserRole['user_role']] as $value){
		      	$p = explode('.', $value);
		        $files[]=$p[0];
		      }
		     }
		    
		$menu='';
		$q='';
		if (is_null($parent_id)) {
			$q = mysqli_query($dbc,"SELECT * FROM menus WHERE parent_id IS NULL OR parent_id=0");
		}else{
			$q = mysqli_query($dbc,"SELECT * FROM menus WHERE parent_id='$parent_id'");
		}
		while ($r=mysqli_fetch_assoc($q)) {
		
		if (!empty($r['page'])) {
			# code...
			$page=explode(".",$r['page']);
			if(in_array($page[0], $files)){
			 
         }
          $menu.='<li  title="'.ucwords($r['title']).'"  class="treeview"><a ondblclick="redirectURL(`index.php?nav='.base64_encode($page[0]).'`)" href="index.php?nav='.base64_encode($page[0]).'">
            <i class="'.$r['icon'].'"></i> <span>'.ucwords($r['title']).'</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>';

          

      
		}else{
			$menu.='<li  title="'.ucwords($r['title']).'" class="treeview"><a href="#">
            <i class="'.$r['icon'].'"></i> <span>'.ucwords($r['title']).'</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>';
         
          
		}
		 $menu.='<ul class="treeview-menu">'.generate_multilevel_menu($dbc,$r['id']).'</ul>';
		$menu.='</li>';
		}//loop
		return $menu;
	}//end

	/*
	Get Last ID
	*/
	function getLastId($dbc,$table,$fld){
		$q=mysqli_fetch_assoc(mysqli_query($dbc,"SELECT * FROM $table ORDER BY $fld DESC LIMIT 1"));
		return $q[$fld];
	}
	/*
	Email SMTP
	*/
	function send_email($email_address,$subject,$email_body){
		global $sts;
 		global $msg;	
		$mail = new PHPMailer;
		 //Tell PHPMailer to use SMTP
		$mail->isSMTP();

		//Enable SMTP debugging
		// 0 = off (for production use)
		// 1 = client messages
		// 2 = client and server messages
		$mail->SMTPDebug = 0;

		//Ask for HTML-friendly debug output
		$mail->Debugoutput = 'html';

		//Set the hostname of the mail server
		$mail->Host = 'smtp.gmail.com';
			
		//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
		$mail->Port = 587;

		//Set the encryption system to use - ssl (deprecated) or tls
		$mail->SMTPSecure = 'tls';

		//Whether to use SMTP authentication
		$mail->SMTPAuth = true;

		//Username to use for SMTP authentication - use full email address for gmail
		$mail->Username = "moixx.ansari43@gmail.com";

		//Password to use for SMTP authentication
		$mail->Password = "3593ab59Moiz";

		//Set who the message is to be sent from
		$mail->setFrom('moixx.ansari43@email.com', 'Tile Select');

		//Set an alternative reply-to address
		//$mail->addReplyTo('replyto@example.com', 'First Last');

		//Set who the message is to be sent to
		$mail->addAddress($email_address, $subject);

		//Set the subject line
		$mail->Subject = $subject;

		//Read an HTML message body from an external file, convert referenced images to embedded,
		//convert HTML into a basic plain-text alternative body
		//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
			 
		$body =$email_body;
		$mail->Body =$body ;

		//Replace the plain text body with one created manually
		$mail->AltBody = 'This is a plain-text message body';
		$mail->isHTML(true);  
		//Attach an image file
		//$mail->addAttachment('images/phpmailer_mini.png');

		//send the message, check for errors
		if (!$mail->send()) {
		    $msg= "Mailer Error: " . $mail->ErrorInfo;
		    $sts="danger";
		} else{
			$msg="Email Sent Successfully...";
			$sts="success";
		}

	}
	?>
	<?php 
	function getVoucherType($data){
		switch ($data) {
			case 'bpv':
				# code...
			$v=('Bank Voucher');
				break;
				case 'apv':
				# code...
			$v=('Account Voucher');
				break;
				case 'jpv':
				# code...
			$v=('Journal Voucher');
				break;
			default:
				# code...
			$v="";
				break;
			
		}
		return $v;
	}
	function getVoucherFile($data){
		switch ($data) {
			case 'bpv':
				# code...
			$file_name=('bank_payment');
				break;
				case 'apv':
				# code...
			$file_name=('account_voucher');
				break;
				case 'jpv':
				# code...
			$file_name=('journal_voucher');
				break;
			default:
				# code...
			$file_name="#";
				break;	
			}
			return $file_name;
		}

	 ?>
<?php @include_once 'inc/code.php'; ?>
