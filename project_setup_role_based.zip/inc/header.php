<?php 
  @$fetchLoginBranch =fetchRecord($dbc,"branch","branch_name",$fetchUser['user_branch']);
 ?>
<style>
  @media (max-width: 767px){
.skin-blue .main-header .navbar .dropdown-menu li a {
    color: #000;
}
@media (max-width: 767px){
.skin-blue .main-header .navbar .dropdown-menu li a:hover {
    background-color: #eee;
}
}
</style>
<header class="main-header">

    <!-- Logo -->
    <a href="./" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>T</b>SL</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Tile</b>Select</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
       <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Tasks: style can be found in dropdown.less -->
          <li>
            <a data-fancybox="gallary" href="img/uploads/<?=@$fetchLoginBranch['branch_logo']?>">
              <img style="margin-top: -10px" width="32" height="32" class="img img-responsive" src="img/uploads/<?=@$fetchLoginBranch['branch_logo']?>">
          </a> 
          </li>
          
          <li class="text-uppercase" style="font-weight: 900;font-size: 1.5em"><a href="#"><?=@$fetchUser['user_branch']?></a></li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <span class="hidden-xs text-capitalize"><?=@$fetchUser['user_fullname']?></span>  <b class="caret"></b>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->

              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="index.php?nav=<?=base64_encode('profile')?>" class="btn btn-primary btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-warning btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <!-- <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a> -->
          </li>
        </ul>
      </div>
    </nav>
  </header>