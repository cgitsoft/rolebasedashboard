 <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

 <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

<!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <link rel="icon" href="img/logo.png">

 <!-- Bootstrap Dropdown Hover CSS -->
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/bootstrap-dropdownhover.min.css" rel="stylesheet">
        <!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- Sparkline -->
<script src="bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap  -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="bower_components/chart.js/Chart.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- DataTables -->
<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="dist/css/fancy.css" />
<script src="dist/js/fancy.js"></script>
  <link rel="stylesheet" href="css/jquery-ui.css">
  <script src="js/bootstrap-dropdownhover.min.js"></script>

<script src="js/jquery-ui.js"></script>
<style>
  .content{
    padding: 0px 15px;
  }
  .box{
    /*margin-top: -40px;*/
  }
  .alert{
    position: relative;
    z-index: 10000;
  }
  /* 
  MULTILEVEL NAVIGATION
   */
     .navigation {
  padding: 0;
  margin: 0;
  border: 0;
  line-height: 1;
}

.navigation ul,
.navigation ul li,
.navigation ul ul {
  list-style: none;
  margin: 0;
  padding: 0;
}

.navigation ul {
  position: relative;
  z-index: 500;
  float: left;
}

.navigation ul li {
  float: left;
  min-height: 0.05em;
  line-height: 1em;
  vertical-align: middle;
  position: relative;
}

.navigation ul li.hover,
.navigation ul li:hover {
  position: relative;
  z-index: 510;
  cursor: default;
}

.navigation ul ul {
  visibility: hidden;
  position: absolute;
  top: 100%;
  left: 0px;
  z-index: 520;
  width: 100%;
}

.navigation ul ul li { float: none; }

.navigation ul ul ul {
  top: 0;
  right: 0;
}

.navigation ul li:hover > ul { visibility: visible; }

.navigation ul ul {
  top: 0;
  left: 99%;
}

.navigation ul li { float: none; }

.navigation ul ul { margin-top: 0.05em; }

.navigation {
  /*width: 13em;*/
  /*background: #333333;*/
  font-family: 'roboto', Tahoma, Arial, sans-serif;
  zoom: 1;
}

.navigation:before {
  content: '';
  display: block;
}

.navigation:after {
  content: '';
  display: table;
  clear: both;
}

.navigation a {
  display: block;
  padding: 1em 1.3em;
  color: #ffffff;
  text-decoration: none;
  text-transform: capitalize;
}

.navigation > ul {/* width: 13em;*/ }

.navigation ul ul { width: 13em; }

.navigation > ul > li > a {
  border-left: 0.3em solid #3C8DBC;
  color: #ffffff;
}

.navigation > ul > li > a:hover { color: #ffffff; }

.navigation > ul > li a:hover,
.navigation > ul > li:hover a { background: #202020; }

.navigation li { position: relative; }

.navigation ul li.has-sub > a:after {
  content: '';
  position: absolute;
  right: 1em;
}

.navigation ul ul li.first {
  -webkit-border-radius: 0 3px 0 0;
  -moz-border-radius: 0 3px 0 0;
  border-radius: 0 3px 0 0;
}

.navigation ul ul li.last {
  -webkit-border-radius: 0 0 3px 0;
  -moz-border-radius: 0 0 3px 0;
  border-radius: 0 0 3px 0;
  border-bottom: 0;
}

.navigation ul ul {
  -webkit-border-radius: 0 3px 3px 0;
  -moz-border-radius: 0 3px 3px 0;
  border-radius: 0 3px 3px 0;
}

.navigation ul ul {/* border: 1px solid #34A65F;*/ }

.navigation ul ul a { color: #ffffff; }

.navigation ul ul a:hover { color: #ffffff; }

.navigation ul ul li { /*border-bottom: 1px solid #0F8A5F;*/ }

.navigation ul ul li:hover > a {
  background: #4eb1ff;
  color: #ffffff;
}

.navigation.align-right > ul > li > a {
  border-left: 0.3em solid #34A65F;
  border-right: none;
}

.navigation.align-right { float: right; }

.navigation.align-right li { text-align: right; }

.navigation.align-right ul li.has-sub > a:before {
  content: '+';
  position: absolute;
  top: 50%;
  left: 15px;
  margin-top: -6px;
}

.navigation.align-right ul li.has-sub > a:after { content: none; }

.navigation.align-right ul ul {
  visibility: hidden;
  position: absolute;
  top: 0;
  left: -100%;
  z-index: 598;
  width: 100%;
}

.navigation.align-right ul ul li.first {
  -webkit-border-radius: 3px 0 0 0;
  -moz-border-radius: 3px 0 0 0;
  border-radius: 3px 0 0 0;
}

.navigation.align-right ul ul li.last {
  -webkit-border-radius: 0 0 0 3px;
  -moz-border-radius: 0 0 0 3px;
  border-radius: 0 0 0 3px;
}

.navigation.align-right ul ul {
  -webkit-border-radius: 3px 0 0 3px;
  -moz-border-radius: 3px 0 0 3px;
  border-radius: 3px 0 0 3px;
}
#ui-datepicker-div{
  z-index: 1000 !important;
}
</style>
<script>
  $(function () {
    $('.myTable1').DataTable()
    $('.myTable2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
  <script>
        document.onkeyup = function(e) {
  if (e.altKey && e.which == 74) {
    $(".jpv_add_row").click();
  } else if (e.altKey && e.which == 66) {
    //ALT + i
    $(".add_row").click();
  } else if (e.altKey && e.which ==73 ) {
    // window.location="index.php?nav=student_installment";
  } else if (e.altKey && e.which == 82) {
    //ALT + R
    // window.location="index.php?nav=attendance_report";
  }
  else if (e.altKey && e.which == 67) {
    //alt + C
    // window.location="print_card.php";
  }

};
</script>
<script>
  $(document).ready(function(){
    // $("#content").load("pages/home.php");
  });
  function redirectURL(url){
    window.location=url;
   /* $("#content").load("pages/"+url, {limit: 25}, 
    function (responseText, textStatus, req) {
        if (textStatus == "error") {
           $("#content").load("pages/404.php");
        }
    });*/
  }
  function deleteData(table,fld,id,url){
      var x = confirm(' Do you want to ID# : '+id);
        if (x==true) {
           $.ajax({
          url:"inc/ajax_deleteData.php",
          type:"post",
          data:{table:table,fld:fld,id:id,url:url},
          dataType:"text",
          success:function(response){
             $(".responseMessage").html(response);
            setTimeout(function(){
               window.location=url;
              $(".responseMessage").html('');
            },1500);
          }
        });
      }
    }
</script>
    <script type="text/javascript">
  

  var imageTypes = ['jpeg', 'jpg', 'png','svg','gif']; //Validate the images to show
        function showImage(src, target)
        {
            var fr = new FileReader();
            fr.onload = function(e)
            {
                target.src = this.result;
            };
            fr.readAsDataURL(src.files[0]);
        }
        var uploadImage = function(obj)
        {
            var val = obj.value;
            var lastInd = val.lastIndexOf('.');
            var ext = val.slice(lastInd + 1, val.length);
            if (imageTypes.indexOf(ext) !== -1)
            {
                var id = $(obj).data('target');                    
                var src = obj;
                var target = $(id)[0];                    
                showImage(src, target);
            }
            else
            {
              obj.value='';
              obj.style.background='yellow';
              alert("only allowed  ('jpeg', 'jpg', 'png','svg','gif') files");

            }
        }

</script>

  <script>
  $( function() {
    // from to date
      var dateFormat = "mm/dd/yy",
      from = $( "#from" )
        .datepicker({
          defaultDate: "-1w",
          changeMonth: true,
          numberOfMonths:1
        })
        .on( "change", function() {
          to.datepicker( "option", "minDate", getDate( this ) );
        }),
      to = $( "#to" ).datepicker({
        defaultDate: "-1w",
        changeMonth: true,
        numberOfMonths:1
      })
      .on( "change", function() {
        from.datepicker( "option", "maxDate", getDate( this ) );
      });
 
    function getDate( element ) {
      var date;
      try {
        date = $.datepicker.parseDate( dateFormat, element.value );
      } catch( error ) {
        date = null;
      }
 
      return date;
    }
    //simple dates
    $( ".dateField" ).datepicker({
      changeMonth: true,
      changeYear: true,
      yearRange: '1945:'+(new Date).getFullYear(),
      dateFormat:'yy-mm-d' 
    });

     $( ".monthDateField" ).datepicker({
      changeMonth: true,
      changeYear: true,
      yearRange: '1945:'+(new Date).getFullYear(),
      dateFormat:'yy-mm' 
    });
  } );
  </script>



<script>
  var gi=0;
    var i=1;
    var total=0;
     $(document).on('click',".add_row",function(){
      
       $("#transaction_row").append('<tr id="remove_row_'+i+'"> <td width="15%"><input  autocomplete="no" type="text" name="account_no[]" readonly class="form-control account_no_cell" id="account_no_cell_'+i+'" title="'+i+'"></td> <td> <input  autocomplete="no" type="text required" name="account_name[]" required class="form-control account_name_cell" id="account_name_cell_'+i+'" title="'+i+'"> </td> <td width="20%"><input type="number" class="form-control amount_input" value="0" name="amount[]"></td> </tr>');
       i++;
    });
     /*Tansaction Journal Voucher*/
      $(document).on('click',".jpv_add_row",function(){
       $("#jpv_transaction_row").append('<tr id="remove_row_'+i+'"> <td width="15%"><input  autocomplete="no" type="text" name="account_no[]" readonly class="form-control account_no_cell" id="account_no_cell_'+i+'" title="'+i+'"></td> <td> <input  autocomplete="no" type="text required" name="account_name[]" required class="form-control account_name_cell" id="account_name_cell_'+i+'" title="'+i+'"> </td> <td width="20%"><input type="number" class="form-control dr_amount_input" id="dr_amount_'+i+'" title="'+i+'"  value="0" name="dr_amount[]"></td><td width="20%"><input type="number" class="form-control cr_amount_input" value="0" id="cr_amount_'+i+'" name="cr_amount[]" title="'+i+'"></td> </tr>');
       i++;
    });
    $(document).on('click',".remove_row",function(){
       if (i<=0) {
        i=1;
      }else{
         i--;
      }
      $("#remove_row_"+i).remove();

      
    });

  $(document).on("change",".payment_mode",function(){
  var payment_mode = $(this).val();
  var txt = '';
  if (payment_mode=="cheque") {
    txt+='<select class="form-control" name="payment_mode_type" id=""> <option value="open">Open</option> <option value="cross">Cross</option></select>';
  }
  else if (payment_mode=="card") {
    txt+='<select class="form-control" name="payment_mode_type" id=""> <option value="master">Master</option> <option value="visa">VISA</option> <option value="debit">Debit</option> </select>';
  }
  else{
    txt+='<input type="text" value="online"  name="payment_mode_type" class="form-control">';
    }
    $(".payment_mode_response").html(txt);
  });
  /*
  Open LOV
  */
  $(document).on("click",".account-lov",function(){
    getAccountList();
  });
  $(document).on("dblclick",".account_name_cell",function(){
    $('#account-show-modal').modal('toggle');
    getAccountList("cell");
    gi=$(this).attr('title');
  });
  function getAccountList(text=""){
    $.get("inc/account.php",{action:"opening balance",accout_lov:1,text:text},function(response){
          $(".account_modal").html(response);
        });//get Account form
  }

  $(document).on("dblclick",".account_row,.account_cell",function(){
    var t = $(this);
    $.ajax({  
                type: "get",  
                url: "inc/account.php",
                data:{action:"get balance",account_id:$(this).attr("title")},
                headers: {Accept : "application/json;charset=utf-8","Content-Type":"application/json;charset=utf-8"},
                success: function(resp){
                console.log(resp); 
                  var responseText = JSON.parse(resp);
            if ($(".account_filter").val()=="account_row") {
               $(".account_name").val(responseText.account_name);
                $("#account_no").val(responseText.account_id);
            $(".account_id").html(responseText.account_id);
            }else{

              $("#account_no_cell_"+gi).val(responseText.account_id);
              $("#account_name_cell_"+gi).val(responseText.account_name);
            }
           
          $('#account-show-modal').modal('toggle');
                 }                
              });
  });//account row
</script>

<script>

   $(document).on('change',".amount_input",function(){
      total=0;
      if ($(this).val()==='') {
        $(this).val(0);
      }
         $(".amount_input").each(function(){
           total=parseInt($(this).val())+parseInt(total);
          });
      $("#total_amount").val(total);
    });
   /*Dr Total*/
   $(document).on('input',".dr_amount_input",function(){

      total=0;
      var di=$(this).attr('title');
        $("#cr_amount_"+di).val(0);
      if ($(this).val()==='') {
        $(this).val(0);
      }

     
      $(".dr_amount_input").each(function(){
   
           total=parseInt($(this).val())+parseInt(total);
          });
      $("#dr_total_amount").val(total);
      checkEquality();
       
    });
    /*CR Total*/
   $(document).on('input',".cr_amount_input",function(){
     
      total=0;
      var ci=$(this).attr('title');
      $("#dr_amount_"+ci).val(0);
      if ($(this).val()==='') {
        $(this).val(0);
      }
       
      $(".cr_amount_input").each(function(){
           total=parseInt($(this).val())+parseInt(total);
          });
      $("#cr_total_amount").val(total);

      checkEquality();
     
       
    });
     function checkEquality(){
      if ($("#dr_total_amount").val()!=$("#cr_total_amount").val()) {
          $("#sum_response").addClass("alert alert-danger");
          $("#sum_response").removeClass("alert-success");
        $("#sum_response").text("Can not proceed because Debit and Credit balances are not equal");
         $("#add_voucher_jpv").addClass("hidden");
      }else{
        $("#add_voucher_jpv").removeClass("hidden");
         $("#sum_response").addClass("alert alert-success");
          $("#sum_response").removeClass("alert-danger");
         $("#sum_response").text("Allowed to Save Record");
      }
     }
     $(document).on('focus',".amount_input,.dr_amount_input,.cr_amount_input",function(){
        $(this).select();
      });

     /*Search Vouchers*/
     function searchVoucher(action=''){
      var start_date =$(".start_date").val();
      var end_date =$(".end_date").val();
      var voucher_type = $("#voucher_type_select").val();
      $.ajax({
        url:"inc/vouchers.php",
        data:{start_date:start_date,end_date:end_date,action:action,voucher_type:voucher_type},
        type:"get",
        dataType:"text",
        success:function(response){
          console.log(response);
          $("#voucherTableResponse").html(response);
        }
      });

     }
     /*
      View Transaction in Modal
     */
     $(document).on("click",".view_transaction",function(){
        $("#transaction-modal").modal("toggle");
        $.ajax({
          url:"inc/transctions.php",
          type:"get",
          dataType:"text",
          data:{voucher_id:$(this).attr("title"),action:"view"},
          success:function(response){
            $(".transaction-body").html(response);
          }
        });
      });
       
  </script>