<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="img/logo.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p> <?=@ucwords($fetchUser['user_fullname'])?></p>
          <a href="./"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
     <!--  <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form> -->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <!-- <li class="active treeview menu-open">
          <a href="./">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        </li> -->
        <!-- <li class="treeview"> -->
          <?php //echo show_menu($dbc);?>
        <!-- </li> -->
      </ul>
    </section>
    <!-- /.sidebar -->
    <div class="navigation" style="">
      <ul>
        <?php foreach (array_unique($parents) as  $p) :
          $unique_parent = fetchRecord($dbc,"menus","id",$p);
          ?>
        <li class="has-sub"> <a href="#"><span class="<?=$unique_parent['icon']?>"></span> </a>
          <ul>
             <?php foreach ($files as  $value) :
              $filename=$value.".php";
             $q= mysqli_query($dbc,"SELECT * FROM menus WHERE parent_id='$p' AND page='$filename'");
             if(mysqli_num_rows($q)==1):
               $navigation = fetchRecord($dbc,"menus","page",$filename);
                if(empty($navigation['parent_id']) AND $navigation['page']=="#"){
                  continue;
                }
               ?>
            <li class="has-sub"> <a href="index.php?nav=<?=base64_encode($value)?>"><?=$navigation['title'];?></a>
            </li>
          <?php endif; ?>
             <?php endforeach; ?>
          </ul>
        </li>
          
      <?php endforeach; ?>
      </ul>
    </div>
  </aside>
