<?php include_once 'functions.php'; ?>
<?php 
	if (isset($_REQUEST['user_list'])) {
		# code...
		if (mysqli_query($dbc,"DELETE FROM assign_user_role WHERE user_id='$_REQUEST[user_list]'")) {
			# code...
		
		foreach($_REQUEST['user_role_list'] as $role):
		$data = [
			'user_id'=>$_REQUEST['user_list'],
			'user_role'=>$role,
			'assign_user_role_remarks'=>"Assign by User: ".$_SESSION['user_login'],
		];
		$q=insert_data($dbc,"assign_user_role",$data);
		
		endforeach;
			if (@$q) {
				# code...
				getMessage("User Role Updated","success");
			}
			else{
				getMessage(mysqli_error($dbc,"danger"));
			}
		}//delete user
		else{
			getMessage(mysqli_error($dbc,"danger"));
		}
	}
 ?>