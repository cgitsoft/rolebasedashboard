<?php include_once 'functions.php'; ?>
<?php 
	if (isset($_REQUEST['user_role_name'])) {
		# code...
		if (mysqli_query($dbc,"DELETE FROM assign_module WHERE user_role='$_REQUEST[user_role_name]'")) {
			# code...
		
		foreach($_REQUEST['user_role_page'] as $page):
		$data = [
			'user_role'=>$_REQUEST['user_role_name'],
			'menu_page'=>$page,
		];
		$q=insert_data($dbc,"assign_module",$data);
		
		endforeach;
			if (@$q) {
				# code...
				getMessage("User Rights Updated","success");
			}
			else{
				getMessage(mysqli_error($dbc,"danger"));
			}
		}//delete user
		else{
			getMessage(mysqli_error($dbc,"danger"));
		}
	}
 ?>