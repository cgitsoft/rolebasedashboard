<div class="box box-body">
	<h1 class="text-center"><img src="img/404.jpg"  width="400" height="400" class="img img-responsive center-block" alt=""></h1>
	<center>
		<h3 class="text-success">Consult the Adminsittrator Authority to grand access</h3>
		<h2><a href="./" class="text-danger"><span class="glyphicon glyphicon-home"></span> Go Back</a></h2>
	</center>
</div>