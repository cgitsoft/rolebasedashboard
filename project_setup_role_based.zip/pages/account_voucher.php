

<div class="panel panel-default">
	<div class="panel-heading">
		<h3 class="panel-title">Add/ Edit Account Vouchers</h3>
	</div><!-- header -->
	<div class="panel-body">
		<form class="row" method="post">
			<input type="hidden" name="voucher_type" value="apv">
			<div class="col-sm-6">
				<div class="form-group">
					<label for="">Session</label>
					<input type="text" class="form-control" name="session" placeholder="Session" required readonly value="<?=date('Y')?>-<?=date('Y')+1?>"> 
				</div><!-- group -->
				<div class="form-group">
					<label for="">Voucher No</label>
					<input type="text" class="form-control" name="voucher_no" placeholder="Voucher No"  readonly required value="APV-<?=$voucher_code_string?>-<?=getLastId($dbc,'vouchers','voucher_id')+1?>"> 
				</div><!-- group -->
			</div><!-- col. -->
			<div class="col-sm-6">
				<div class="form-group">
					<label for="">Invoice No</label>
					<input type="text" class="form-control" name="invoice_no" placeholder="Invoice No" required> 
				</div><!-- group -->
				<div class="form-group">
					<label for="">Voucher Date</label>
					<input type="text" class="form-control dateField" name="voucher_date" required="" placeholder="Voucher Date" autocomplete="off"> 
				</div><!-- group -->
			</div><!-- col -->
			<div class="col-sm-12">
				<div class="input-group">
					<input type="hidden" name="account_id" id="account_no">
					<label for="" class="input-group-addon account_id" >Bank Account#</label>
					<input autocomplete="no" type="text" class="form-control account_name" placeholder="" name="bank_account">
					<label class="input-group-btn">
						<button type="button" data-target="#account-show-modal" data-toggle="modal" class="btn btn-warning account-lov">Open Account List</button>
					</label>
				</div><!-- group -->
			</div><!-- col -->
			<div class="col-sm-12">
				<div class="form-group">
					<label for="">Nurration</label>
					<textarea name="description" id="" cols="30" rows="4" class="form-control" placeholder="Nurration"></textarea>
				</div><!-- group -->
			</div><!-- col -->
			<div class="col-sm-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title">Transaction</h3> 
						<div class="btn-group pull-right">
							<button type="button" class="btn btn-success add_row">+</button>
							<button type="button" class="btn btn-danger remove_row">-</button>
						</div><!-- group -->
					</div>
					<div class="panel-body">
						<table id="transaction_row"  class="table table-bordered table-condensed table-striped">
							<tr>
								<th>A/C No</th>
								<th>A/C Name</th>
								<th>Amount</th>
							</tr>
							<tr>
								<td width="15%"><input readonly autocomplete="no" type="text" class="form-control account_no_cell" name="account_no[]" id="account_no_cell_0" title="0"></td>
								<td>
									<input autocomplete="no" type="text" class="form-control account_name_cell" required name="account_name[]" id="account_name_cell_0" title="0">
								</td>
								<td width="20%"><input type="number" class="form-control amount_input" name="amount[]" value="0"></td>
							</tr>
						</table>
						<div class="col-sm-3 col-sm-offset-9">
							<div class="input-group">
								<label for="" class="input-group-addon">Total: </label>
								<input type="text" class="pull-right form-control" id="total_amount" name="total_amount" value="0" readonly>
							</div><!-- group -->
						</div><!-- col -->
					</div><!-- body -->
				</div><!-- panle -->
			</div><!-- col -->
			<div class="col-sm-12">
				<div class="form-group">
				<button class="btn btn-success" type="submit" name="add_voucher">Add</button>
			</div><!-- group -->
			</div>
		</form><!-- row -->
	</div><!-- body -->
</div><!-- panel -->
<div class="modal fade" id="account-show-modal">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Account List</h4>
			</div>
			<div class="modal-body account_modal">
				
			</div><!-- body -->
			<div class="modal-footer">
				<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>


