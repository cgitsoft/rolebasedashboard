<div class="panel panel-default panel-body" style="padding: 20px">
	<div class="row">
		<div class="col-sm-8 pull-right">
			 <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Latest User Roles</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin myTable1">
                  <thead>
                  <tr>
                    <th>Role ID</th>
                    <th>Role Name</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody class="text-capitalize">
                  	<?php $q = mysqli_query($dbc,"SELECT * FROM user_roles");
                  	while($r=mysqli_fetch_assoc($q)):
                  	 ?>
                  	<tr>
                  		<td><?=$r['user_role_id']?></td>
                  		<td><?=$r['user_role_name']?></td>
                  		<td><?=getEnDis($r['user_role_status'])?></td>
                  		<td>
                  			 <a href="#"  onclick="deleteData('user_roles','user_role_id',<?=$r['user_role_id']?>,'index.php?nav=<?=$_REQUEST["nav"]?>')" class="btn btn-danger btn-xs">Delete</a> |
                  			<a href="index.php?nav=<?=$_REQUEST['nav']?>&edit_user_role_id=<?=base64_encode($r['user_role_id'])?>" class="btn btn-primary btn-xs">Edit</a>  
                  		</td>
                  	</tr>
                  <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
		</div><!-- col -->
		<div class="col-sm-4 panel panel-default panel-body">
			<form action="" method="post" class="ajax_form">
				<div class="form-group">
					<label for="">Role Name</label>
					<input type="text" name="user_role_name" class="form-control" placeholder="Role Name" required value="<?=@$fetchUserRoleData['user_role_name']?>">
				</div><!-- group -->
				<div class="form-group">
					<label for="">Status</label>
					<select name="user_role_status" id="" class="form-control">
            <?php getSelectTag(@$fetchUserRoleData['user_role_status'],"Select Status"); ?>
						<option value="enable">Enable</option>
						<option value="disable">Disable</option>
					</select>
				</div><!-- group -->
				<?=@$user_role_btn?>
			</form>
		</div><!-- col -->
	</div><!-- row -->
</div><!-- box -->
