<div class="box box-info">
	<div class="box-header  with-border">
		<h3>Assign Rights to Roles</h3>
	</div><!-- header -->
	<form class="user_role_right_form" method="post" action="inc/update_user_role_rights.php">
		<div class="row">
			<div class="col-sm-4 col-sm-offset-1">
				<div class="box-body panel panel-default panel-body">
					<h3>Application  Roles</h3>
					<hr>
					<?php $getUserRole=mysqli_query($dbc,"SELECT * FROM user_roles WHERE user_role_status='enable'");
					while($fetchUserRole = mysqli_fetch_assoc($getUserRole)):
					 ?>
					 <div class="radio">
					 	<label class="lead">
					 		<input id="user_role_radio" type="radio" name="user_role_name" value="<?=$fetchUserRole['user_role_name']?>"> <?=ucwords($fetchUserRole['user_role_name']);?>
					 	</label>
					 </div><!-- checkbox -->
					<?php endwhile; ?>
				</div><!-- user application -->
			</div><!-- col -->
			<div class="col-sm-6  panel panel-default panel-body">
				<div class="box-body" id="list_role">
					<h3>Application  Modules</h3>
					<hr>
					<span id="user_role_response">
					<?php $getMenu=mysqli_query($dbc,"SELECT * FROM menus WHERE parent_id IS NOT NULL");
					while($fetchMenu = mysqli_fetch_assoc($getMenu)):
					 ?>
					 <div class="radio">
					 	<label class="lead">
					 		<input type="checkbox" name="user_role_list[]" value="<?=$fetchMenu['page']?>"> <?=ucwords($fetchMenu['title']);?>
					 	</label>
					 </div><!-- checkbox -->
					<?php endwhile; ?>
				</span>
				</div><!-- user application -->
			</div><!-- col -->
		</div><!-- row -->
		<button class="btn btn-primary hidden user_role_right_btn pull-right" type="submit">Update User Role</button>
	</form><!-- body -->
</div>
<!-- Box -->

<script>
	$(document).on('change',"#user_role_radio",function(){
		getUserRoleRights($(this).val());
	});
	function getUserRoleRights(user_role){
		$.get("inc/ajax_user_role_rights.php",{user_role:user_role},function(response){
			$("#user_role_response").html(response);
			$(".user_role_right_btn").removeClass('hidden');
		});
	}
	$(".user_role_right_form").unbind().bind('submit',function(){
		var form = $(this);
		$.ajax({
			url:form.attr('action'),
			type:form.attr('method'),
			dataType:'text',
			data:form.serialize(),
			success:function(response){
				$(".responseMessage").html(response);
				$(".alert").show().delay(2500).slideUp(800);
			}
		});
		return false;
	});
</script>