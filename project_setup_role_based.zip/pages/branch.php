<div class="">
	<div class="row">
		<div class="col-sm-8 pull-right">
			 <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Manage Branch Record</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <!-- <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin myTable1">
                  <thead>
                  <tr>
                    <th>Branch ID</th>
                    <th>Logo</th>
                    <th>Branch Name</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody class="text-capitalize">
                  	<?php $q = mysqli_query($dbc,"SELECT * FROM branch");
                  	while($r=mysqli_fetch_assoc($q)):
                  	 ?>
                  	<tr>
                  		<td><?=$r['branch_id']?></td>
                  		<td>
                      <a data-fancybox="gallery" href="img/uploads/<?=$r['branch_logo']?>">
                        <img src="img/uploads/<?=$r['branch_logo']?>" class="img img-responsive" width="40" height="40" alt="">
                      </a>  
                      </td>
                  		<td><?=$r['branch_name']?></td>
                  		<td>
                  			 <a href="#"  onclick="deleteData('branch','branch_id',<?=$r['branch_id']?>,'index.php?nav=<?=$_REQUEST["nav"]?>')" class="btn btn-danger btn-xs">Delete</a> |
                  			<a href="index.php?nav=<?=$_REQUEST['nav']?>&edit_branch_id=<?=base64_encode($r['branch_id'])?>" class="btn btn-primary btn-xs">Edit</a>  
                  		</td>
                  	</tr>
                  <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
		</div><!-- col -->
		<div class="col-sm-4 panel panel-default panel-body">
			<form action="" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<label for="">Branch Name</label>
					<input type="text" name="branch_name" class="form-control" placeholder="Branch Name" required value="<?=@$fetchBranchData['branch_name']?>">
				</div><!-- group -->
				<div class="form-group">
					<label for="">Upload Logo</label>
          
             <div class="form-group"> 
             <?php if(!empty($fetchBranchData['branch_name'])): ?>
               <img src="img/uploads/<?=$fetchBranchData['branch_logo']?>" class="img img-responsive" width="70" height="70"  alt="" id="aImgShow">
              <?php else: ?>
                 <img src="img/user_default.png" class="img img-responsive" width="70" height="70"  alt="" id="aImgShow">
              <?php endif; ?>
             
                <br><input type="file" id="img" class="" onChange="uploadImage(this)" data-target="#aImgShow"  name="f">    
                <p class="text-muted text-center" style="font-size: 11px">
                    Only .png , .jpg , .gif and .jpeg files are allowed
                  </p>
                </div>
				</div><!-- group -->
				<?=@$branch_btn?>
			</form>
		</div><!-- col -->
	</div><!-- row -->
</div><!-- box -->
