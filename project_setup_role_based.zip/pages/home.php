<div class="box box-body">
  <h3 class="text-center">Application is under contruction Please user sidebar for menu by <span class="text-danger">Double Click</span></h3>
  <hr>
  
</div>