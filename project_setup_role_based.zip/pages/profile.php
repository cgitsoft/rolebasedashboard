<div class="box">
	<div class="box-header">
		<h3>Update Profile</h3>
	</div>
	<div class="box-body">
		<form action="" method="post">
			<div class="row">
				<div class="col-sm-6">
					<div class="panel panel-default panel-body">
						<div class="form-group">
							<label for="">User Full Name</label>
							<input type="text" name="user_fullname" value="<?=@$fetchUser['user_fullname']?>" class="form-control">
						</div><!-- group -->
						<div class="form-group">
							<label for="">User Address</label>
							<textarea name="user_address" class="form-control" id="" cols="30" rows="4"><?=@$fetchUser['user_address']?></textarea>
						</div><!-- group -->
					</div><!-- panel -->
				</div><!-- col -->
				<div class="col-sm-6">
					<div class="panel panel-default panel-body">
						<div class="form-group">
							<label for="">User Name</label>
							<input type="text" name="username" value="<?=@$fetchUser['username']?>" class="form-control">
						</div><!-- group -->
						<div class="form-group">
							<label for="">User Email</label>
							<input type="text" name="user_email" value="<?=@$fetchUser['user_email']?>" class="form-control">
						</div><!-- group -->
						<div class="form-group">
							<label for="">User Branh</label>
							<input disabled type="text" name="user_branch" value="<?=@$fetchUser['user_branch']?>" class="form-control">
						</div><!-- group -->
					</div><!-- panel -->	
				</div><!-- col -->
			</div><!-- row -->
			<button class="btn btn-primary" name="update_user_profile">Update Profile</button>
		</form>
		<hr>
		<div class="panel panel-default panel-body">
			<h3>Change Password</h3>
		<form action="" method="post">
		          <div class="from-group"><label for="">Old password</label><input type="password" class="form-control" name="old_password" placeholder="Old Password"></div>
		          <div class="from-group"><label for="">New password</label><input type="password" class="form-control" name="new_password" placeholder="New Password"></div>
		          <div class="from-group"><label for="">Confirm password</label><input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password"></div><br>
		          <button class="btn btn-success" name="update_password">UPDATE PASSWORD</button>
	    </form>
	</div>
	</div><!-- body -->
</div><!-- box -->