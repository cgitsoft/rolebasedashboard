<div class="box">
	<div class="box-header">
		<h3 class="text-center">User Role Management</h3>
	</div><!-- header -->
	<form class="user_role_form" method="post" action="inc/update_user_role.php">
		<div class="row">
			<div class="col-sm-4 col-sm-offset-1">
				<div class="panel panel-default panel-body">
					<div class="box-body" id="list_user">
					<h4>User Application</h4>
					<hr>
					<?php $getUsers=mysqli_query($dbc,"SELECT * FROM users WHERE user_status='enable'");
					while($fetchUsers = mysqli_fetch_assoc($getUsers)):
					 ?>
					 <div class="radio">
					 	<label class="lead">
					 		<input id="user_list" type="radio" name="user_list" value="<?=$fetchUsers['user_id']?>"> <?=$fetchUsers['user_id'];?># <?=$fetchUsers['username'];?>
					 	</label>
					 </div><!-- checkbox -->
					<?php endwhile; ?>
				</div><!-- user application -->
				</div><!-- panel -->
			</div><!-- col -->
			<div class="col-sm-6">
				<div class="panel panel-default panel-body">
					<div class="box-body" id="list_role">
					<h4>Application  Roles</h4>
					<hr>
					<span id="user_role_response">
					<?php $getUserRole=mysqli_query($dbc,"SELECT * FROM user_roles WHERE user_role_status='enable'");
					while($fetchUserRole = mysqli_fetch_assoc($getUserRole)):
					 ?>
					 <div class="radio">
					 	<label class="lead">
					 		<input type="checkbox" name="user_role_list[]" value="<?=$fetchUserRole['user_role_name']?>"> <?=ucwords($fetchUserRole['user_role_name']);?>
					 	</label>
					 </div><!-- checkbox -->
					<?php endwhile; ?>
				</span>
				</div><!-- user application -->
				</div><!-- body -->
			</div><!-- col -->
		</div><!-- row -->
		<button class="btn btn-primary pull-right hidden user_role_btn" type="submit">Update User Role</button>
	</form><!-- body -->
</div>
<!-- Box -->

<script>
	$(document).on('change',"#user_list",function(){
		getUserRole($(this).val());
	});
	function getUserRole(user_list){
		$.get("inc/ajax_user_role.php",{user_list:user_list},function(response){
			$("#user_role_response").html(response);
			$(".user_role_btn").removeClass('hidden');
		});
	}
	$(".user_role_form").unbind().bind('submit',function(){
		var form = $(this);
		$.ajax({
			url:form.attr('action'),
			type:form.attr('method'),
			dataType:'text',
			data:form.serialize(),
			success:function(response){
				$(".responseMessage").html(response);
				$(".alert").show().delay(2500).slideUp(800);
			}
		});
		return false;
	});
</script>