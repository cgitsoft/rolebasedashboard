<div class="box">
	<div class="box-header">
		<h3>Manage Users</h3>
	</div><!-- header -->
	<div class="box-body">
		<div class="row">
			<div class="col-sm-12">
				<form action="" method="POST" role="form">
					<legend>Add Users</legend>
					<div class="row">
						<div class="col-sm-6">
							<div class="panel panel-default panel-body">
							<div class="form-group">
								<label for="">User ID#</label>
								<input type="text" class="form-control"  placeholder="User ID#" value="<?=(!empty($fetchUserData['user_id'])?$fetchUserData['user_id']:getLastId($dbc,'users','user_id')+1)?>" disabled>
							</div><!-- group -->
							<div class="form-group">
								<label for="">Full Name</label>
								<input type="text" class="form-control" id="" placeholder="Full Name" name="user_fullname" value="<?=@$fetchUserData['user_fullname']?>" required>
							</div><!-- group -->
							<div class="form-group">
								<label for="">Username</label>
								<input type="text" class="form-control" id="" placeholder="User Name" name="username" value="<?=@$fetchUserData['username']?>" required>
								<div class="form-group">
								<label for="">User Branh</label>
								<select name="user_branch" id="" class="form-control">
									<?php getSelectTag($fetchUserData['user_branch'],"Select Branch"); ?>
									<?php $getBranch = mysqli_query($dbc,"SELECT * FROM branch ORDER BY branch_name ASC");
									while($fetchBranch=mysqli_fetch_assoc($getBranch)):
									 ?>
									<option value="<?=$fetchBranch['branch_name']?>"><?=ucwords($fetchBranch['branch_name'])?></option>
								<?php endwhile; ?>
								</select>
							</div><!-- group -->
							</div><!-- group -->
							<?=@$user_btn?>
						</div><!-- panel -->
							
						</div><!-- col -->
						<div class="col-sm-6">
							<div class="panel panel-default panel-body">
							<div class="form-group">
								<label for="">Email</label>
								<input type="email" class="form-control" id="" placeholder="Email" name="user_email" value="<?=@$fetchUserData['user_email']?>">
							</div><!-- group -->
							<div class="form-group">
								<label for="">Password</label>
								<input type="text" class="form-control" id="" placeholder="Password" name="user_password" value="<?=@$fetchUserData['user_password']?>" required>
								<p class="text-danger"><b>Note: </b> Password above you enter will be changed to encrypted format</p>
							</div><!-- group -->
							<div class="form-group">
								<label for="">User Address</label>
								<textarea placeholder="Address" name="user_address" class="form-control" id="" cols="30" rows="3"><?=@$fetchUserData['user_address']?></textarea>
							</div><!-- group -->
							<div class="form-group">
								<label for="">Status</label>
								<select name="user_status" id="" class="form-control">
			            		<?php getSelectTag(@$fetchUserData['user_status'],"Select Status"); ?>
									<option value="enable">Enable</option>
									<option value="disable">Disable</option>
								</select>
							</div><!-- group -->
						</div><!-- panel -->
						</div><!-- col -->
					</div><!-- row -->
				</form>
			</div><!-- col -->
			<div class="col-sm-12">
				<div class="table-responsive panel panel-default panel-body">
					<table class="table table-hover myTable1">
						<thead>
							<tr>
								<th>User ID#</th>
								<th>Full Name</th>
								<th>Details</th>
								<th>Branch</th>
								<th>Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $q=mysqli_query($dbc,"SELECT * FROM users WHERE user_created_id='$fetchUser[user_id]'");
							while($r=mysqli_fetch_assoc($q)):
							 ?>
							<tr>
								<td><?=$r['user_id']?></td>
								<td class="text-uppsercase"><?=$r['user_fullname']?></td>
								<td>
									<strong>User Name: </strong> <?=$r['username']?> <br>
									<strong>Email: </strong><a href="mailto:<?=$r['user_email']?>"><?=$r['user_email']?></a><br>
									<!-- <strong>Password: </strong><?=$r['user_password']?> -->
								</td>
								<td><?=$r['user_branch']?></td>
								<td class="text-uppercase"><?=getEnDis($r['user_status'])?></td>
								<td>
									 <a href="#"  onclick="deleteData('users','user_id',<?=$r['user_id']?>,'index.php?nav=<?=$_REQUEST["nav"]?>')" class="btn btn-danger btn-xs">Delete</a> |
		                  			<a href="index.php?nav=<?=$_REQUEST['nav']?>&edit_user_id=<?=base64_encode($r['user_id'])?>" class="btn btn-primary btn-xs">Edit</a>  
								</td>
							</tr>
						<?php endwhile; ?>
						</tbody>
					</table>
				</div>
			</div><!-- col -->
		</div><!-- row -->
	</div><!-- body -->
</div><!-- box -->