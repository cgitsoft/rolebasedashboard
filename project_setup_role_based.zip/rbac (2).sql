-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2019 at 06:40 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rbac`
--

-- --------------------------------------------------------

--
-- Table structure for table `assign_module`
--

CREATE TABLE `assign_module` (
  `assign_module_id` int(11) NOT NULL,
  `user_role` varchar(300) DEFAULT NULL,
  `menu_page` varchar(300) DEFAULT NULL,
  `assign_module_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign_module`
--

INSERT INTO `assign_module` (`assign_module_id`, `user_role`, `menu_page`, `assign_module_add_date`) VALUES
(13, 'developer', 'add_remove_user_roles.php', '2019-02-13 21:03:21'),
(14, 'developer', 'user_role_management.php', '2019-02-13 21:03:22'),
(30, 'branch manager', 'branch.php', '2019-02-14 17:10:52'),
(141, 'administrator', 'assign_rights.php', '2019-03-10 14:00:17'),
(142, 'administrator', 'add_remove_user_roles.php', '2019-03-10 14:00:17'),
(143, 'administrator', 'users.php', '2019-03-10 14:00:17'),
(144, 'administrator', 'user_role_management.php', '2019-03-10 14:00:17'),
(145, 'administrator', 'branch.php', '2019-03-10 14:00:18'),
(146, 'administrator', 'chart_of_accounts.php', '2019-03-10 14:00:18'),
(147, 'administrator', 'bank_payment.php', '2019-03-10 14:00:18'),
(148, 'administrator', 'journal_voucher.php', '2019-03-10 14:00:18'),
(149, 'administrator', 'account_voucher.php', '2019-03-10 14:00:18'),
(150, 'administrator', 'search_voucher.php', '2019-03-10 14:00:18'),
(151, 'administrator', 'month.php', '2019-03-10 14:00:18'),
(152, 'Accountant', 'bank_payment.php', '2019-03-23 17:01:24'),
(153, 'Accountant', 'search_voucher.php', '2019-03-23 17:01:24');

-- --------------------------------------------------------

--
-- Table structure for table `assign_user_role`
--

CREATE TABLE `assign_user_role` (
  `assign_user_role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_role` varchar(300) DEFAULT NULL,
  `assign_user_role_remarks` text,
  `assign_user_role_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign_user_role`
--

INSERT INTO `assign_user_role` (`assign_user_role_id`, `user_id`, `user_role`, `assign_user_role_remarks`, `assign_user_role_add_date`) VALUES
(15, 5, 'administrator', 'Assign by User: admin@admin.com', '2019-02-10 20:09:56'),
(16, 5, 'branch manager', 'Assign by User: admin@admin.com', '2019-02-10 20:09:56'),
(17, 4, 'branch manager', 'Assign by User: admin@admin.com', '2019-02-10 20:13:16'),
(18, 2, 'developer', 'Assign by User: admin@admin.com', '2019-02-10 21:00:07'),
(19, 2, 'branch manager', 'Assign by User: admin@admin.com', '2019-02-10 21:00:07'),
(33, 1, 'administrator', 'Assign by User: admin', '2019-02-28 19:20:26'),
(34, 7, 'Accountant', 'Assign by User: admin', '2019-03-23 17:01:32');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(500) DEFAULT NULL,
  `branch_logo` varchar(300) NOT NULL DEFAULT 'user_default.png',
  `branch_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `branch_logo`, `branch_add_date`) VALUES
(1, 'head office', '120655c64a59b409fc.png', '2019-02-07 10:34:16'),
(2, 'susan road office', '24405c64a54bd1980.png', '2019-02-07 10:34:16'),
(4, 'new branch', '192095c649c1024481.png', '2019-02-13 22:37:04');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `title` text,
  `page` text,
  `parent_id` int(11) DEFAULT NULL,
  `icon` varchar(300) NOT NULL DEFAULT 'fa fa-link',
  `sort_order` varchar(20) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `title`, `page`, `parent_id`, `icon`, `sort_order`, `created_date`) VALUES
(4, 'Assign Rights to Roles', 'assign_rights.php', 5, 'fa fa-check', NULL, '2019-02-05 19:47:33'),
(5, 'Users', '#', NULL, 'fa fa-users', '3', '2019-02-05 19:47:58'),
(6, 'add/remove user roles', 'add_remove_user_roles.php', 5, 'fa fa-cog', NULL, '2019-02-05 20:33:23'),
(7, 'add/remove users', 'users.php', 5, 'fa fa-users', NULL, '2019-02-05 20:33:23'),
(9, 'User Role Management', 'user_role_management.php', 5, 'fa fa-cog', NULL, '2019-02-10 19:04:56'),
(11, 'Manage Branch', 'branch.php', 11, 'fa fa-link', NULL, '2019-02-13 22:07:26'),
(24, 'Accounts', '#', 0, 'fa fa-link', NULL, '2019-02-28 19:25:07'),
(25, 'Chart of Accounts', 'chart_of_accounts.php', 24, 'fa fa-link', NULL, '2019-02-28 19:25:43'),
(26, 'Voucher', '', 24, 'fa fa-link', NULL, '2019-03-02 17:33:01'),
(27, 'Bank Payment', 'bank_payment.php', 26, 'fa fa-link', NULL, '2019-03-02 17:39:10'),
(28, 'Journal Voucher', 'journal_voucher.php', 26, 'fa fa-link', NULL, '2019-03-02 17:39:49'),
(29, 'Account Voucher', 'account_voucher.php', 26, 'fa fa-link', NULL, '2019-03-03 11:22:30'),
(30, 'Search Voucher', 'search_voucher.php', 26, 'fa fa-link', NULL, '2019-03-03 21:05:08'),
(31, 'Reports', '#', 0, 'fa fa-link', NULL, '2019-03-10 13:59:35'),
(32, 'Monthly Report', 'month.php', 31, 'fa fa-link', NULL, '2019-03-10 14:00:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `user_email` varchar(400) DEFAULT NULL,
  `user_password` text,
  `user_fullname` varchar(300) DEFAULT NULL,
  `user_branch` varchar(300) DEFAULT NULL,
  `user_address` text,
  `user_status` varchar(300) NOT NULL DEFAULT 'enable',
  `user_created_id` int(11) DEFAULT NULL,
  `user_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `user_email`, `user_password`, `user_fullname`, `user_branch`, `user_address`, `user_status`, `user_created_id`, `user_add_date`) VALUES
(1, 'admin', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', 'admin admin', 'head office', 'house # 66 B Block Gulberg Colony Faisalabad , 38000', 'enable', NULL, '2019-02-06 11:23:46'),
(2, 'newuser', 'new@user.com', 'e6b306857e5d4afe00114863b6fbc795', 'new user', 'susan road office', 'nill', 'enable', 1, '2019-02-08 06:08:50'),
(4, 'moixx', 'moixx.ansari43@gmail.com', '2a77d9de907385ebf2b94d6b35fbcdd0', 'MOIZ IQBAL', 'susan road office', 'House # 66 B Block Gulberg Colony Faisalabad', 'enable', 1, '2019-02-08 07:02:20'),
(5, 'abd', 'abd@gmail.com', '202cb962ac59075b964b07152d234b70', 'Abdul Rehman', 'head office', 'House # 236 Street # 3 Green Town Umer Block', 'enable', 1, '2019-02-08 12:35:01'),
(6, 'moiziqbal', 'moiz.iqbal55@gmail.com', '8ca8f0e38f2823572277e322026317a8', 'Moiz Iqbal', 'head office', 'House 66 B Block Gulberg Colony Fsd', 'enable', 1, '2019-02-15 05:29:02'),
(7, 'rizwan', 'rizwan@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Rizwan', 'new branch', 'House # 66 B Block Gulberg Colony Faisalabad', 'enable', 1, '2019-03-23 17:01:02');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_role_id` int(11) NOT NULL,
  `user_role_name` varchar(300) DEFAULT NULL,
  `user_role_status` varchar(300) NOT NULL DEFAULT 'enable',
  `user_role_add_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`user_role_id`, `user_role_name`, `user_role_status`, `user_role_add_date`) VALUES
(1, 'administrator', 'enable', '2019-02-07 19:26:05'),
(3, 'developer', 'enable', '2019-02-07 19:59:38'),
(5, 'branch manager', 'enable', '2019-02-07 20:02:24'),
(6, 'Accountant', 'enable', '2019-03-23 17:00:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assign_module`
--
ALTER TABLE `assign_module`
  ADD PRIMARY KEY (`assign_module_id`);

--
-- Indexes for table `assign_user_role`
--
ALTER TABLE `assign_user_role`
  ADD PRIMARY KEY (`assign_user_role_id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`),
  ADD UNIQUE KEY `branch_name` (`branch_name`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_role_id`),
  ADD UNIQUE KEY `user_role_name` (`user_role_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assign_module`
--
ALTER TABLE `assign_module`
  MODIFY `assign_module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;
--
-- AUTO_INCREMENT for table `assign_user_role`
--
ALTER TABLE `assign_user_role`
  MODIFY `assign_user_role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
  MODIFY `user_role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
